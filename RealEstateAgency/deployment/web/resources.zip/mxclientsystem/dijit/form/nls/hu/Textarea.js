//>>built
define("dijit/form/nls/hu/Textarea",({iframeEditTitle:"szerkesztési terület",iframeFocusTitle:"szerkesztési terület keret"}));
