//>>built
define("dijit/form/nls/nb/Textarea",({iframeEditTitle:"redigeringsområde",iframeFocusTitle:"ramme for redigeringsområde"}));
