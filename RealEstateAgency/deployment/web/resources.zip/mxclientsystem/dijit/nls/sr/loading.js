//>>built
define("dijit/nls/sr/loading",{loadingState:"Učitavanje...",errorState:"Nažalost, došlo je do greške"});
