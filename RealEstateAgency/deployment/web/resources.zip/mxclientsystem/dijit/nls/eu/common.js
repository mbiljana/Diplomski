//>>built
define("dijit/nls/eu/common",{buttonOk:"Ados",buttonCancel:"Utzi",buttonSave:"Gorde",itemClose:"Itxi"});
